import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Link, NavLink} from 'react-router-dom'
import './App.css';
import LoginPage from './pages/LoginPage'
import SignUpPage from './pages/SignUpPage'
import Table from './Table';
import Form from './Form'




class App extends Component {


  removeCharacter = index => {
    const { characters } = this.state
  
    this.setState({
      characters: characters.filter((character, i) => {
        return i !== index
      }),
    })
  }

  state = {
    characters: [  {
      name: 'Charlie',
      job: 'Janitor',
    },
    {
      name: 'Mac',
      job: 'Bouncer',
    },
    {
      name: 'Dee',
      job: 'Aspring actress',
    },
    {
      name: 'Dennis',
      job: 'Bartender',
    },]
  };

  render() {

    const { characters } = this.state
   
    return (
      <Router>
      <div className="App">

          
          <div className="App__Aside">
            <a
              className="App-link"
              href="https://hltv.org"
              target="_blank"
              rel="noopener"
            >
              hltv
            </a>
          </div>
          <div className="App__Form">
            <div className="PageSwitch">
              <NavLink to="/login" activeClassName="PageSwitcher PageSwitcher--Active" className="PageSwitcher"> Zaloguj</NavLink>
              <NavLink exact to="/" activeClassName="PageSwitcher PageSwitcher--Active" className="PageSwitcher">Zarejestruj</NavLink>
            </div>

            <div className="FormTitle">
              <NavLink to="/login" activeClassName="FormTitle__Link--Active" className="FormTitle__Link"> Zaloguj</NavLink> lub 
              <NavLink exact to="/" activeClassName="FormTitle__Link--Active" className="FormTitle__Link">
              Zarejestruj</NavLink>
            </div>
            <Route exact path="/" component={SignUpPage}>
            </Route>

            <Route path="/login" component={LoginPage}>
            </Route>
 
          </div>
      </div>
      </Router>
      
    );
  }
}

export default App;
