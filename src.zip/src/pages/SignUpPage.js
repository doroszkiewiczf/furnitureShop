import React, { Component } from 'react';
import {Link} from 'react-router-dom';

const formValid = formErrors => {
  let valid = true;

  Object.values(formErrors).forEach(val => {
    val.length > 0 && (valid = false);
  });
  return valid;
}

function validateEmail(email) {
  var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(String(email).toLowerCase());
}

class SignUpPage extends Component{

  constructor(){
    super();

    this.state = {
      login: '',
      password: '',
      email: '',
      isAccepted: false,
      formErrors: {
        login: '',
        password: '',
        email: '' 
      }
    };
  }

  handleChange = e => {
    e.preventDefault();
    const target = e.target;
    let value = target.type === 'checkbox' ? target.checked : target.value;
    let name = target.name;
    let formErrors = this.state.formErrors;

    switch(name){
      case "login":
        formErrors.login = value.length < 3  ? "zła długość loginu" : "";
        break;
      case "password":
        formErrors.password = value.length < 6 ? "za krótkie hasło here" : "";
        break;
      case "email":
        formErrors.email = validateEmail(value) ? "" : "zły mail";
        break;
      case "isAccepted"
      default:
        break;
    }
    this.setState({formErrors, [name]: value});
  }
  handleSubmit = e => {
      e.preventDefault();
      if (this.state.isAccepted){
        if (formValid(this.state.formErrors)){
          console.log('Zalogowano here danymi:');
          console.log(this.state);
        }
        else{
          console.error("SOMETHING IS WRONG");
          console.error(this.state.formErrors);
        }
      }

  }

    render(){
      const {formErrors} = this.state;
        return(
            <div onSubmit={this.handleSubmit} className="FormCenter">

                <form className="FormFields">
                  {/*Pole tekstowe - login*/}
                  <div className="FormField">
                    <label className="FormField__Label" htmlFor="name"> Login: </label>
                    <input type="text" id="login" className="FormField__Input"
                    placeholder="Podaj login" name="login" value={this.state.login} 
                    onChange={this.handleChange}/>
                    {formErrors.login.length > 0 && (
                    <span className="errorMessage">{formErrors.login}</span>
                  )}

                  </div>
                  
                  {/*Pole tekstowe - hasło*/}
                  <div className="FormField">
                    <label className="FormField__Label" htmlFor="password"> Hasło: </label>
                    <input type="text" id="password" className="FormField__Input"
                    placeholder="Podaj hasło twoje" name="password" value={this.state.password}
                    onChange={this.handleChange}/>
                    {formErrors.password.length > 0 && (
                    <span className="errorMessage">{formErrors.password}</span>
                  )}
                  </div>

                  {/*Pole tekstowe - email*/}
                  <div className="FormField">
                    <label className="FormField__Label" htmlFor="email"> E-mail: </label>
                    <input type="text" id="email" className="FormField__Input"
                    placeholder="Podaj swego mejla" name="email" value={this.state.email}
                    onChange={this.handleChange}/>
                    {formErrors.email.length > 0 && (
                    <span className="errorMessage">{formErrors.email}</span>
                  )}
                  </div>

                  {/*Check box do akceptacji*/}
                    <div className="FormField">
                      <label className="FormField__CheckboxLabel">
                        <input className="FormField__Checkbox" type="checkbox" name="isAccepted"
                        value={this.state.isAccepted} onChange={this.handleChange}/>
                        Jestem pedałem opisane tutaj - 
                        <a href="https://hltv.org" target="_blank" rel="noopener noreferrer" className="FormField__TermsLink"> regulamin</a>
                      </label>
                    </div>
                  {/*Przycisk do akceptacji*/}
                  <div className="FormField">
                    <button className="FormField__Button mr-20"> Zarejestruj</button>
                    <Link to="/login" className="FormField__Link">Mam już konto mordo</Link>

                  </div>
                </form>  
              </div>
        );
    }
}

export default SignUpPage;